import React, { useState } from 'react';
import { 
  Search, 
  Star, 
  MapPin, 
  User, 
  Clock, 
  CheckCircle, 
  Calendar,
  Settings,
  Home,
  Bell,
  ArrowLeft,
  Shovel,
  X
} from 'lucide-react';
import { VoiceSearch } from './components/VoiceSearch';
import { ServiceCategories } from './components/ServiceCategory';
import { SettingsModal } from './components/SettingsModal';
import { RatingModal } from './components/RatingModal';
import { ThankYouModal } from './components/ThankYouModal';
import { RequestProgress } from './components/RequestProgress';

function App() {
  const [searchQuery, setSearchQuery] = useState('');
  const [showProfile, setShowProfile] = useState(false);
  const [selectedWorker, setSelectedWorker] = useState(null);
  const [showSettings, setShowSettings] = useState(false);
  const [showRating, setShowRating] = useState(false);
  const [showThankYou, setShowThankYou] = useState(false);
  const [selectedRequest, setSelectedRequest] = useState(null);
  const [showRequestDetails, setShowRequestDetails] = useState(false);

  const currentUser = {
    name: 'José Sánchez',
    image: 'https://images.unsplash.com/photo-1599566150163-29194dcaad36?q=80&w=100&h=100&fit=crop'
  };

  const workers = [
    {
      id: 1,
      job: 'Fontanero',
      name: 'Juan Pérez',
      rating: 4.8,
      jobs: 120,
      location: 'Trujillo Centro',
      price: 70.00,
      image: 'https://images.unsplash.com/photo-1506803682981-6e718a9dd3ee?q=80&w=200&h=200&fit=crop',
      description: 'Especialista en instalaciones y reparaciones de sistemas de agua y desagüe.',
      skills: ['Instalaciones', 'Reparaciones', 'Mantenimiento preventivo', 'Emergencias 24/7']
    }
  ];

  const recentRequests = [
    { 
      id: 1, 
      service: 'Fontanería', 
      worker: 'Juan Pérez', 
      status: 'completed', 
      date: '2024-03-15',
      completedDate: '2024-03-15T16:30:00'
    },
    { 
      id: 2, 
      service: 'Electricidad', 
      worker: 'María García', 
      status: 'in-progress', 
      date: '2024-03-16',
      startDate: '2024-03-16T09:00:00',
      estimatedDays: 3,
      estimatedEndDate: '2024-03-19T17:00:00'
    },
    { 
      id: 3, 
      service: 'Carpintería', 
      worker: 'Carlos López', 
      status: 'scheduled', 
      scheduledDate: '2024-03-18T10:00:00',
      estimatedDuration: '4 horas'
    }
  ];

  const handleWorkerProfile = (worker) => {
    setSelectedWorker(worker);
    setShowProfile(true);
  };

  const handleVoiceResult = (text) => {
    setSearchQuery(text);
  };

  const handleRating = (request) => {
    setSelectedRequest(request);
    setShowRating(true);
  };

  const handleRatingSubmit = (rating, comment) => {
    console.log('Rating submitted:', { rating, comment });
    setShowRating(false);
    setShowThankYou(true);
  };

  const handleRequestClick = (request) => {
    setSelectedRequest(request);
    setShowRequestDetails(true);
  };

  return (
    <div className="min-h-screen bg-white">
      {/* Navigation Bar */}
      <nav className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 py-3 px-6 z-40">
        <div className="max-w-6xl mx-auto flex justify-around items-center">
          <button className="flex flex-col items-center text-green-600">
            <Home size={24} />
            <span className="text-xs mt-1">Inicio</span>
          </button>
          <button className="flex flex-col items-center text-gray-600">
            <Search size={24} />
            <span className="text-xs mt-1">Buscar</span>
          </button>
          <button className="flex flex-col items-center text-gray-600">
            <Bell size={24} />
            <span className="text-xs mt-1">Notificaciones</span>
          </button>
          <button className="flex flex-col items-center text-gray-600">
            <User size={24} />
            <span className="text-xs mt-1">Perfil</span>
          </button>
        </div>
      </nav>

      {showProfile && selectedWorker ? (
        <div className="min-h-screen bg-white p-4">
          <div className="max-w-6xl mx-auto">
            <button 
              onClick={() => setShowProfile(false)}
              className="flex items-center text-gray-600 mb-4"
            >
              <ArrowLeft size={24} />
              <span className="ml-2">Volver</span>
            </button>
            
            <div className="bg-white rounded-lg shadow-md p-6">
              <div className="flex items-center gap-4 mb-6">
                <img
                  src={selectedWorker.image}
                  alt={selectedWorker.name}
                  className="w-24 h-24 rounded-full object-cover"
                />
                <div>
                  <h2 className="text-2xl font-bold">{selectedWorker.name}</h2>
                  <p className="text-gray-600">{selectedWorker.job}</p>
                  <div className="flex items-center mt-2">
                    {[...Array(5)].map((_, i) => (
                      <Star
                        key={i}
                        size={16}
                        className={i < Math.floor(selectedWorker.rating) ? "fill-yellow-400 text-yellow-400" : "text-gray-300"}
                      />
                    ))}
                    <span className="ml-2">{selectedWorker.rating} ({selectedWorker.jobs} trabajos)</span>
                  </div>
                </div>
              </div>

              <div className="mb-6">
                <h3 className="text-lg font-semibold mb-2">Descripción</h3>
                <p className="text-gray-600">{selectedWorker.description}</p>
              </div>

              <div className="mb-6">
                <h3 className="text-lg font-semibold mb-2">Habilidades</h3>
                <div className="flex flex-wrap gap-2">
                  {selectedWorker.skills.map((skill, index) => (
                    <span key={index} className="bg-green-100 text-green-700 px-3 py-1 rounded-full text-sm">
                      {skill}
                    </span>
                  ))}
                </div>
              </div>

              <button className="w-full bg-green-600 text-white py-3 rounded-lg hover:bg-green-700 transition-colors">
                Solicitar Servicio
              </button>
            </div>
          </div>
        </div>
      ) : (
        <>
          {/* Header */}
          <header className="bg-green-600 text-white py-6 px-4">
            <div className="max-w-6xl mx-auto flex justify-between items-center">
              <div className="flex items-center gap-3">
                <Shovel size={32} />
                <h1 className="text-3xl font-bold">BuscaChamba</h1>
              </div>
              <button 
                onClick={() => setShowSettings(true)} 
                className="p-2 hover:bg-green-700 rounded-full"
              >
                <Settings size={24} />
              </button>
            </div>
          </header>

          {/* Welcome Section */}
          <div className="max-w-6xl mx-auto mt-8 px-4">
            <div className="flex items-center gap-4">
              <img
                src={currentUser.image}
                alt={currentUser.name}
                className="w-16 h-16 rounded-full object-cover"
              />
              <div>
                <h2 className="text-2xl font-bold">Bienvenido, {currentUser.name}</h2>
                <p className="text-gray-600">¿Qué servicio necesitas hoy?</p>
              </div>
            </div>
          </div>

          {/* Service Categories */}
          <div className="max-w-6xl mx-auto mt-8 px-4">
            <ServiceCategories />
          </div>

          {/* Search Bar */}
          <div className="max-w-6xl mx-auto mt-8 px-4">
            <div className="flex gap-2">
              <div className="flex-1 relative">
                <input
                  type="text"
                  placeholder="Buscar servicio..."
                  className="w-full py-3 px-4 pr-12 rounded-lg border border-gray-300 focus:ring-2 focus:ring-green-500 focus:border-transparent"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
                <VoiceSearch onResult={handleVoiceResult} />
              </div>
              <button className="bg-green-600 text-white px-6 rounded-lg hover:bg-green-700 flex items-center gap-2">
                <Search size={20} />
                Buscar
              </button>
            </div>
          </div>

          {/* Recommended Workers */}
          <section className="max-w-6xl mx-auto mt-12 px-4">
            <h2 className="text-2xl font-bold mb-6">Recomendaciones Personalizadas</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {workers.map((worker) => (
                <div key={worker.id} className="bg-white rounded-lg shadow-md p-4 border border-gray-100">
                  <div className="flex gap-4">
                    <img
                      src={worker.image}
                      alt={worker.name}
                      className="w-20 h-20 rounded-full object-cover"
                    />
                    <div className="flex-1">
                      <h3 className="font-semibold text-lg">{worker.job}</h3>
                      <p className="text-gray-600">{worker.name}</p>
                      <div className="flex items-center gap-1 mt-1">
                        {[...Array(5)].map((_, i) => (
                          <Star
                            key={i}
                            size={16}
                            className={i < Math.floor(worker.rating) ? "fill-yellow-400 text-yellow-400" : "text-gray-300"}
                          />
                        ))}
                        <span className="text-sm text-gray-600 ml-1">
                          {worker.rating} ({worker.jobs} trabajos)
                        </span>
                      </div>
                      <div className="flex items-center gap-1 text-gray-600 text-sm mt-1">
                        <MapPin size={14} />
                        {worker.location}
                      </div>
                      <div className="flex items-center justify-between mt-2">
                        <span className="font-bold text-green-600">S/.{worker.price.toFixed(2)}</span>
                        <div className="flex gap-2">
                          <button 
                            onClick={() => handleWorkerProfile(worker)}
                            className="p-2 text-gray-600 hover:bg-gray-100 rounded-full"
                          >
                            <User size={20} />
                          </button>
                          <button className="bg-green-600 text-white px-4 py-1 rounded-lg hover:bg-green-700">
                            Solicitar
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </section>

          {/* Recent Requests */}
          <section className="max-w-6xl mx-auto mt-12 mb-24 px-4">
            <h2 className="text-2xl font-bold mb-6">Tus Solicitudes Recientes</h2>
            <div className="space-y-4">
              {recentRequests.map((request) => (
                <div 
                  key={request.id} 
                  className="bg-white rounded-lg shadow-md p-4 border border-gray-100 cursor-pointer hover:shadow-lg transition-shadow"
                  onClick={() => handleRequestClick(request)}
                >
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="font-semibold">{request.service}</h3>
                      <p className="text-gray-600">{request.worker}</p>
                      {request.status === 'in-progress' && (
                        <p className="text-sm text-blue-600">
                          Tiempo estimado: {request.estimatedDays} días
                        </p>
                      )}
                      {request.status === 'scheduled' && (
                        <p className="text-sm text-orange-600">
                          {new Date(request.scheduledDate).toLocaleDateString('es-ES', {
                            weekday: 'long',
                            year: 'numeric',
                            month: 'long',
                            day: 'numeric',
                            hour: '2-digit',
                            minute: '2-digit'
                          })}
                        </p>
                      )}
                    </div>
                    <div className="flex items-center gap-2">
                      {request.status === 'completed' && (
                        <>
                          <span className="flex items-center gap-1 text-green-600">
                            <CheckCircle size={20} />
                            Completado
                          </span>
                          <button 
                            onClick={(e) => {
                              e.stopPropagation();
                              handleRating(request);
                            }}
                            className="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700"
                          >
                            Calificar
                          </button>
                        </>
                      )}
                      {request.status === 'in-progress' && (
                        <span className="flex items-center gap-1 text-blue-600">
                          <Clock size={20} />
                          En Proceso
                        </span>
                      )}
                      {request.status === 'scheduled' && (
                        <span className="flex items-center gap-1 text-orange-600">
                          <Calendar size={20} />
                          Programado
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* Request Details Modal */}
            {showRequestDetails && selectedRequest && (
              <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center">
                <div className="bg-white rounded-lg w-full max-w-2xl mx-4 p-6">
                  <div className="flex justify-between items-center mb-4">
                    <h2 className="text-2xl font-bold">{selectedRequest.service}</h2>
                    <button 
                      onClick={() => setShowRequestDetails(false)}
                      className="p-2 hover:bg-gray-100 rounded-full"
                    >
                      <X size={20} />
                    </button>
                  </div>

                  <div className="mb-6">
                    <h3 className="font-semibold text-lg mb-2">Detalles del Servicio</h3>
                    <p className="text-gray-600">Trabajador: {selectedRequest.worker}</p>
                    {selectedRequest.status === 'scheduled' && (
                      <>
                        <p className="text-gray-600">
                          Fecha programada: {new Date(selectedRequest.scheduledDate).toLocaleDateString('es-ES', {
                            weekday: 'long',
                            year: 'numeric',
                            month: 'long',
                            day: 'numeric',
                            hour: '2-digit',
                            minute: '2-digit'
                          })}
                        </p>
                        <p className="text-gray-600">Duración estimada: {selectedRequest.estimatedDuration}</p>
                      </>
                    )}
                  </div>

                  <RequestProgress 
                    status={selectedRequest.status}
                    startDate={selectedRequest.startDate || selectedRequest.scheduledDate}
                    estimatedEndDate={selectedRequest.estimatedEndDate || selectedRequest.scheduledDate}
                    completedDate={selectedRequest.completedDate}
                  />

                  <div className="mt-6 flex justify-end">
                    <button
                      onClick={() => setShowRequestDetails(false)}
                      className="bg-gray-100 text-gray-700 px-6 py-2 rounded-lg hover:bg-gray-200 transition-colors"
                    >
                      Cerrar
                    </button>
                  </div>
                </div>
              </div>
            )}
          </section>
        </>
      )}

      {/* Modals */}
      <SettingsModal isOpen={showSettings} onClose={() => setShowSettings(false)} />
      <RatingModal 
        isOpen={showRating} 
        onClose={() => setShowRating(false)}
        onSubmit={handleRatingSubmit}
        workerName={selectedRequest?.worker || ''}
        service={selectedRequest?.service || ''}
      />
      <ThankYouModal isOpen={showThankYou} onClose={() => setShowThankYou(false)} />
    </div>
  );
}

export default App;