import React from 'react';
import { X, Bell, Lock, Globe, Moon, HelpCircle, LogOut } from 'lucide-react';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function SettingsModal({ isOpen, onClose }: SettingsModalProps) {
  if (!isOpen) return null;

  const settingsOptions = [
    { icon: <Bell size={20} />, label: 'Notificaciones', description: 'Gestionar alertas y avisos' },
    { icon: <Lock size={20} />, label: 'Privacidad', description: 'Configurar visibilidad y datos' },
    { icon: <Globe size={20} />, label: 'Idioma', description: 'Cambiar idioma de la aplicación' },
    { icon: <Moon size={20} />, label: 'Tema', description: 'Cambiar entre claro y oscuro' },
    { icon: <HelpCircle size={20} />, label: 'Ayuda', description: 'Centro de soporte' },
  ];

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center">
      <div className="bg-white rounded-lg w-full max-w-md mx-4">
        <div className="flex justify-between items-center p-4 border-b">
          <h2 className="text-xl font-bold">Ajustes</h2>
          <button onClick={onClose} className="p-2 hover:bg-gray-100 rounded-full">
            <X size={20} />
          </button>
        </div>
        
        <div className="p-4 space-y-4">
          {settingsOptions.map((option) => (
            <button
              key={option.label}
              className="w-full flex items-center gap-4 p-3 hover:bg-gray-50 rounded-lg transition-colors"
            >
              <div className="text-gray-600">{option.icon}</div>
              <div className="text-left">
                <div className="font-medium">{option.label}</div>
                <div className="text-sm text-gray-500">{option.description}</div>
              </div>
            </button>
          ))}
          
          <button className="w-full flex items-center gap-4 p-3 text-red-600 hover:bg-red-50 rounded-lg transition-colors">
            <LogOut size={20} />
            <span className="font-medium">Cerrar sesión</span>
          </button>
        </div>
      </div>
    </div>
  );
}