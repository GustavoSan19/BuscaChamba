import React, { useState } from 'react';
import { Home, Wrench, Building } from 'lucide-react';

interface Service {
  name: string;
  icon: React.ReactNode;
  subservices: string[];
}

const services: Service[] = [
  {
    name: 'Servicios Domésticos',
    icon: <Home className="w-8 h-8" />,
    subservices: ['Limpieza', 'Jardinería', 'Cocina', 'Cuidado de mascotas']
  },
  {
    name: 'Servicios de Mantenimiento',
    icon: <Wrench className="w-8 h-8" />,
    subservices: ['Fontanería', 'Electricidad', 'Carpintería', 'Pintura']
  },
  {
    name: 'Servicios Públicos',
    icon: <Building className="w-8 h-8" />,
    subservices: ['Trámites', 'Gestiones', 'Asesoría legal', 'Contabilidad']
  }
];

export function ServiceCategories() {
  const [expandedService, setExpandedService] = useState<string | null>(null);

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
      {services.map((service) => (
        <div key={service.name} className="space-y-2">
          <button
            onClick={() => setExpandedService(expandedService === service.name ? null : service.name)}
            className="w-full bg-green-50 hover:bg-green-100 text-green-700 font-semibold py-4 px-6 rounded-lg transition-colors flex items-center gap-3"
          >
            {service.icon}
            <span>{service.name}</span>
          </button>
          
          {expandedService === service.name && (
            <div className="bg-white rounded-lg shadow-md p-4 space-y-2">
              {service.subservices.map((subservice) => (
                <button
                  key={subservice}
                  className="w-full text-left px-4 py-2 text-gray-700 hover:bg-green-50 rounded-lg transition-colors"
                >
                  {subservice}
                </button>
              ))}
            </div>
          )}
        </div>
      ))}
    </div>
  );
}